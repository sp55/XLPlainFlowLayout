//
//  XLPlainFlowLayout.h
//  XLPlainFlowLayout
//
//  Created by hebe on 15/7/30.
//  Copyright (c) 2015年 ___ZhangXiaoLiang___. All rights reserved.
//
//  工作邮箱E-mail: k52471@126.com

#import <UIKit/UIKit.h>

@interface XLPlainFlowLayout : UICollectionViewFlowLayout

@property (nonatomic, assign) CGFloat naviHeight;//默认为64.0, default is 64.0

@end
