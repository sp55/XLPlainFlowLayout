//
//  CollectionViewCell0.h
//  XLPlainFlowLayoutDemo
//
//  Created by admin on 2017/11/2.
//  Copyright © 2017年 ___ZhangXiaoLiang___. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CollectionViewCell0 : UICollectionViewCell
@property(strong,nonatomic)UILabel *textLabel;

@end
