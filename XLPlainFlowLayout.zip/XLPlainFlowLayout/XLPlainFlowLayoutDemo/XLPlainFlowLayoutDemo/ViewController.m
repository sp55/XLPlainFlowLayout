//
//  ViewController.m
//  XLPlainFlowLayoutDemo
//
//  Created by hebe on 15/7/30.
//  Copyright (c) 2015年 ___ZhangXiaoLiang___. All rights reserved.
//

#import "ViewController.h"
#import "ReusableView.h"
#import "XLPlainFlowLayout.h"
#import "CollectionViewCell0.h"
#import "CollectionViewCell1.h"
#import "MJRefresh.h"

@interface ViewController ()<UICollectionViewDelegateFlowLayout>
@property(strong,nonatomic)NSMutableArray *dataArr;

@property(strong,nonatomic)NSArray *array;
@end

@implementation ViewController
static NSString *cellID = @"cellID";
static NSString *cellID0 = @"cellID0";
static NSString *cellID1 = @"cellID1";

static NSString *headerID = @"headerID";
static NSString *footerID = @"footerID";


-(instancetype)init
{
    XLPlainFlowLayout *layout = [XLPlainFlowLayout new];
    layout.itemSize = CGSizeMake(100, 100);
    layout.sectionInset = UIEdgeInsetsMake(10, 10, 10, 10);
    layout.naviHeight = 44.0;

    return [self initWithCollectionViewLayout:layout];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"XLPlainFlowLayoutDemo";
    
    
    [self.dataArr addObjectsFromArray:self.array];
    
    self.collectionView.backgroundColor = [UIColor whiteColor];
    [self.collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:cellID];
    [self.collectionView registerClass:[ReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader  withReuseIdentifier:headerID];
    [self.collectionView registerClass:[ReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionFooter  withReuseIdentifier:footerID];
    
    [self.collectionView registerClass:[CollectionViewCell0 class] forCellWithReuseIdentifier:cellID0];
    [self.collectionView registerClass:[CollectionViewCell1 class] forCellWithReuseIdentifier:cellID1];

    self.collectionView.backgroundColor = [UIColor lightGrayColor];
    
    self.collectionView.mj_header =[MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self loadFirstPage];
    }];
    
    self.collectionView.mj_footer =[MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self loadNextPage];
    }];
}

-(NSArray *)array{
    if (!_array) {
        _array = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10",@"11",@"12",@"13",@"14",@"15",@"16",@"17",@"18",@"19",@"20",@"21",@"22"];
    }
    return _array;
}

-(void)loadFirstPage{
    
    [self.dataArr removeAllObjects];
    
    [self.dataArr addObjectsFromArray:self.array];

    
    [self.collectionView reloadData];
    
    
    [self.collectionView.mj_header endRefreshing];


}
-(void)loadNextPage{
    
    [self.dataArr addObjectsFromArray:self.array];
    
    
    [self.collectionView reloadData];
    
    [self.collectionView.mj_footer endRefreshing];

}

#pragma mark - 10组
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 2;
}
#pragma mark - 每组的个数
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section==1) {
        return self.dataArr.count;
    }
    return 0;
}
#pragma mark  - 数据
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section==1) {
        NSLog(@"==xxxxx===%ld",self.dataArr.count);
        CollectionViewCell0 *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID0 forIndexPath:indexPath];
        cell.backgroundColor = [UIColor cyanColor];
        cell.textLabel.text = [NSString stringWithFormat:@"第%ld个",indexPath.item];
        return cell;

    }
    CollectionViewCell1 *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellID1 forIndexPath:indexPath];
    cell.backgroundColor = [UIColor redColor];
    cell.textLabel.text = @"11111";
    return cell;

}
#pragma mark - 头或者尾
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath {

    
    if (indexPath.section ==1) {
        ReusableView *header = [collectionView  dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:headerID forIndexPath:indexPath];
        header.backgroundColor = [UIColor blackColor] ;
        header.text = [NSString stringWithFormat:@"组头"];
        return header;
    }
    return nil;
}
#pragma mark - cell的头的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    if (section==1) {
        return CGSizeMake(0, 44);
    }
    return CGSizeZero;
}
#pragma mark - cell的尾的大小
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
//    if (section==0) {
//        return CGSizeMake(0, 20);
//    }
    return CGSizeZero;

}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==1) {
        return  CGSizeMake(100, 100);
    }
    return CGSizeMake([[UIScreen mainScreen] bounds].size.width, 60);
}
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    if (section==1) {
        return UIEdgeInsetsMake(10, 10, 10, 10);
    }
    return UIEdgeInsetsMake(0, 0, 0, 0 );
}
-(BOOL)prefersStatusBarHidden
{
    return YES;
}
-(NSMutableArray *)dataArr{
    if (!_dataArr) {
        _dataArr = [NSMutableArray array];
    }
    return _dataArr;
}


@end
