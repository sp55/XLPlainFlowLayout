

//
//  CollectionViewCell1.m
//  XLPlainFlowLayoutDemo
//
//  Created by admin on 2017/11/2.
//  Copyright © 2017年 ___ZhangXiaoLiang___. All rights reserved.
//

#import "CollectionViewCell1.h"

@implementation CollectionViewCell1
-(instancetype)initWithFrame:(CGRect)frame{
    if (self=[super initWithFrame:frame]) {
        
        self.textLabel = [[UILabel alloc] initWithFrame:self.bounds];
        self.textLabel.textColor = [UIColor whiteColor];
        self.textLabel.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.textLabel];
    }
    return self;
}
@end
