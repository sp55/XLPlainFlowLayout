# XLPlainFlowLayout
可以让UICollectionView的header也支持悬停效果，类似于tableView的Plain风格

新浪微博：[亮亮亮亮亮靓啊](http://www.weibo.com/zxliang7)

![](https://github.com/HebeTienCoder/XLPlainFlowLayout/raw/master/demo.gif)  
